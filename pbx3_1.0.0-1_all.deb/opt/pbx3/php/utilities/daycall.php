<?php
#
#----------------------------------------------------------------------
# heading     : CODENAME
# description : Daycall
# Copyright   (c) kokokraft.com       2024  
#
#----------------------------------------------------------------------
#----------------------------------------------------------------------
#  
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 		
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 		
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
# 
# Technical support for this program is available from Selintra Ltd
# Please visit our web site www.selintra.com/ for details.
#----------------------------------------------------------------------
#
## untested in p3!!!!!!!!!!!
#
include("generated_file_banner.php");
include("localvars.php");
include __DIR__ . "/../config.php";

try {
    /*** connect to SQLite database ***/

    $dbh = new PDO(SYSDB);

    /*** set the error reporting attribute ***/
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
    echo $e->getMessage();
    die("couldn't open DB");
}   

$exten = $argv[1];
$today = trim (`date +%F`);
$email = NULL;
$inbound = NULL;
$outbound = NULL;
$inbtotal = 0;
$outbtotal = 0;
$footer = NULL;
$calls = array();
$emailaddr = NULL;

$res = $dbh->query("SELECT SUPEMAIL FROM globals where pkey = 'global'")->fetch(PDO::FETCH_ASSOC);
$emailaddr =  $res['SUPEMAIL'];
$date = trim(`date +%F`);
echo "date is " . $date;
if ($exten) {
    $calls = `cat /var/log/asterisk/cdr-csv/Master.csv | grep $date | grep $exten`;
	$email .= "\nDear User, \n\nHere is a summary of calls today $today for extension $exten \n\n";
	$sql = $dbh->prepare("SELECT vmailfwd FROM ipphone where pkey = ?");
	$sql->execute(array($exten));
	$res = $sql->fetch();
	if ($res) {
		$emailaddr = $res['vmailfwd'];
	}      
}
else {
    $calls = `cat /var/log/asterisk/cdr-csv/Master.csv | grep $date`;
	$email .= "\nDear User, \n\nHere is a summary of calls today $today \n\n";
}
$call_list = explode("\n",$calls);
//print_r($call_list);

if (!$emailaddr) {
	die("$today  CDR print-request failed for $exten - no email addresses available\n");
	return;
} 
$to = "To: ".$emailaddr;
//$exten =~ /(^\d{4}$)/;
//$exten = $1;
$footer = "\n\tPrinted by PBX3\n";
$outbound .= "OUTBOUND CALLS\n";
$outbound .= sprintf ("\t%15s\t %15s\t %14s\t\t %4s\n\n", 'FROM', 'TO', 'TIME', 'DURATION');
$inbound .= "\n\n";
$inbound .= "INBOUND CALLS\n";
$inbound .= sprintf ("\t%15s\t %15s\t %14s\t\t %4s\n\n", 'FROM', 'TO', 'TIME', 'DURATION');

foreach ($call_list as $call) {

	$fields = explode( ',',$call);
	if (preg_match( " /i/ ",$fields[2])) {
		$fields[2] = "Missdial";
		}
      if   ($fields[1] == $exten || strlen ($fields[1]) < 5 ) { 
		$outbound .= sprintf ("\t%15s %4s %15s %4s %14s %4s %4s\n", $fields[1], " ", $fields[2], " ", $fields[9], " ", $fields[13]);
		$outbtotal = $outbtotal + $fields[13];
		}
	else {
		$inbound .= sprintf ("\t%15s %4s %15s %4s %14s %4s %4s\n", $fields[1], " ", $fields[2], " ", $fields[9], " ", $fields[13]);
		$inbtotal = $inbtotal + $fields[13];
		}
	} 

$outbound .= "\n";
$inbound .= "\n"; 

$outbound .= sprintf ("Total Seconds On Call %7s\n", $outbtotal);
$inbound .= sprintf ("Total Seconds On Call %7s\n",  $inbtotal);

print $email.$outbound.$inbound.$footer;    
$sendmail = "/usr/lib/sendmail -t";
$reply_to = "Reply-to: admin\@selintra.com";
$subject = "Subject: Daily Calls";
print  $reply_to."\n";
print  $subject."\n";
print  $to."\n";
print  "Content-type: text/plain\n\n";
//print  $email.$outbound.$inbound.$footer;


/*
open(SENDMAIL, "|$sendmail") or die "Cannot open $sendmail: $!";
print SENDMAIL $reply_to."\n";
print SENDMAIL $subject."\n";
print SENDMAIL $to."\n";
print SENDMAIL "Content-type: text/plain\n\n";
print SENDMAIL $email.$outbound.$inbound.$footer;
close(SENDMAIL);
*/
