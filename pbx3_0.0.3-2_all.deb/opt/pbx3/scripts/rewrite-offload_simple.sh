date >>/var/log/recdump.log
. /opt/pbx3/scripts/bashconfig
#
# HAS TO BE REWRITTEN FOR S3 RECORDINGS STORE - WILL MOVE TO PHP DUE TO THE INDEX MANAGEMENT 
#
#set this rsync to point to your offload or nearline media
#create directory tree if it doesn't exist
#
#[ ! -d /opt/pbx3/media/recordings ] && mkdir -p /opt/pbx3/media/recordings
##Move the files
#rsync  --remove-source-files -a /var/spool/asterisk/monout/ /opt/pbx3/media/recordings/`date +%d%m%y`/ >>/var/log/recdump.log 2>&1